#!/bin/bash

############################################
#
# sudo apt-get install dos2unix
# dos2unix stop.sh
#
###########################################


echo "=="$(date  +"%Y-%m-%d %H:%M:%S")"=="
mkdir log  >/dev/null 2>&1

STOPEDFILE=.stoped.flag
BIN=/ehd/bin/poc
IP=`/sbin/ifconfig | grep enp1s0 -A 3|grep 'inet.*192' | awk -F' ' '{print $2}' | awk '{print $1}'`

Stop() {
    echo "Stop POC Network";
    killflag=0
    pidlist=`ps -elf | grep -E "$BIN\s" | grep -v grep | awk '{print $4}'`;
    for pid in $pidlist;
    do
        killflag=1
        kill $pid ;
    done;

    if [ $killflag -ge 1 ]; then
        sleep 0.1;
        echo "-----";
        ps -elf | grep poc| grep -v grep;
        echo "stop done"
    else
        echo "$BIN is not running";
    fi

    touch $STOPEDFILE
}

Stop
