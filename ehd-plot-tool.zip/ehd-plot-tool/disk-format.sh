#!/bin/bash

############################################
#
# sudo apt-get install dos2unix
# dos2unix disk-format.sh
#
###########################################

EHDDIR="/ehd"
if [[ ! -d "$EHDDIR/bin" ]]; then
    mkdir -p "$EHDDIR/bin"
fi
chmod -R 0777 $EHDDIR

# /ehd-disk/p1/plotdata 1-16
EHDDISKDIR="/ehd-disk"
if [[ ! -d $EHDDISKDIR ]]; then
  mkdir -p $EHDDISKDIR
fi
chmod -R 0777 $EHDDISKDIR

for i in {1..24}
do
  PLOTDATADIR="$EHDDISKDIR/p$i/plotdata"
  if [[ ! -d $PLOTDATADIR ]]; then
      mkdir -p $PLOTDATADIR
      chmod -R 0777 $PLOTDATADIR
  fi
done

#Ascii value of "a"
ALETTERASCIIVALUE=$(printf %d\\n \'a)
for i in {1..24}
do
  PLOTDATADIR="$EHDDISKDIR/p$i"
  if ! grep -qs $PLOTDATADIR /proc/mounts; then
    CHARASCII=$[i + ALETTERASCIIVALUE]
    CHAR=$(echo $CHARASCII | awk '{printf("%c",$1)}')
    MOUNTDEVICE="/dev/sd$CHAR"

    #disk has been parted
    PARTIONFLAG="sd$CHAR"
    if ! grep -qs "$PARTIONFLAG" /proc/partions; then
      if [[ -b "$MOUNTDEVICE" ]]; then
         # 自动分区
         DEVINFO=$(file -s $MOUNTDEVICE)
         if [[ $DEVINFO != *"ext4"* ]]; then
            mkfs -t "ext4" $MOUNTDEVICE
         fi

         FREE=$(df -k --output=avail "$MOUNTDEVICE" | tail -n1)
         if [[ "$FREE" -gt "0" ]]; then
            umount $MOUNTDEVICE
            mount $MOUNTDEVICE $PLOTDATADIR
         fi
       fi
     fi
   fi
done
