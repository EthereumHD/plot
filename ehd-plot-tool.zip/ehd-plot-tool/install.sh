#!/bin/bash

############################################
#
# sudo apt-get install dos2unix
# dos2unix install.sh
#
###########################################


Install () {
  EHDPATH="/ehd"
  EHDDISKPATH="/ehd-disk"
  CURRENTDIR=`pwd`
  MAC=$(cat /sys/class/net/$(ip route show default | awk '/default/ {print $5}')/address)
  NOW=$(date +"%Y-%m-%d %H:%M:%S")

  HOMEDIR="/home/ehd"

  POCDIR=$HOMEDIR"/.poc"
  if [[ ! -d "$POCDIR" ]]; then
      mkdir -p "$POCDIR"
      chmod -R 0777 "$POCDIR"
  fi

  if [[ ! -d "$POCDIR"/keystore ]]; then
      mkdir -p "$POCDIR"/keystore
      chmod -R 0777 "$POCDIR"/keystore
  fi


  if [[ -f "$CURRENTDIR"/poc ]]; then
     mv "$CURRENTDIR"/poc "$EHDPATH"/bin/poc
     chmod -R  0777 $EHDPATH
  fi

  chmod -R  0777 $EHDPATH
  chmod -R  0777 $POCDIR

  #创建矿机挖矿地址
  if [[ -f "$EHDPATH"/bin/poc ]]; then
     PASSWORD="ehd123123"
     # "$EHDPATH"/bin/poc account new --password "./password" --datadir $POCDIR
     echo -e $PASSWORD"\n"$PASSWORD"\n" | "$EHDPATH"/bin/poc account new --datadir $POCDIR
     cp -R "$POCDIR"/keystore/* "$HOMEDIR"/桌面
     chmod -R 0777 "$POCDIR"/keystore
  fi

  if [[ -f "$CURRENTDIR/database.sqlite" ]]; then
     cp "$CURRENTDIR/database.sqlite" "$EHDPATH"/bin
     cp "$CURRENTDIR/database.sqlite" "$EHDPATH"

     KEYSTOREFILES=`ls $POCDIR/keystore`

     #echo "${files[0]}"
     FIRSTKEYSTOREFILE="${KEYSTOREFILES[0]}"

     if [[ -f $POCDIR/keystore/$FIRSTKEYSTOREFILE ]] ; then
       KEYSTORECONTENT="`cat $POCDIR/keystore/$FIRSTKEYSTOREFILE`"

       ADDRESS=`cat $POCDIR/keystore/$FIRSTKEYSTOREFILE | jq '.address'`

       if [[ ${#ADDRESS} == 40 ]];then
         ADDRESS="0x"$ADDRESS
       sqlite3 $EHDPATH/database.sqlite " DELETE FROM t_host;INSERT INTO t_host(F_Hostname, F_Status, F_CreateTime,F_ModifyTime) VALUES(\"EHD-miner-$MAC\",0,\"$NOW\",\"$NOW\");DELETE FROM t_user;INSERT INTO t_user(F_Username,F_Password, F_CreateTime, F_ModifyTime) VALUES(\"$ADDRESS\", \"ehd123123\", \"$NOW\", \"$NOW\");DELETE FROM t_plot;INSERT INTO t_plot(F_Name, F_Path, F_Uuid, F_PlotSeed, F_PlotDir, F_PlotSize, F_PlotParam, F_Status, F_CreateTime, F_ModifyTime) VALUES('', \"/ehd-disk/p1\", '',  \"$ADDRESS\",  \"/plotdata/\", \"8589934592\", '{\"startNonce\":0}', 0, \"$NOW\", \"$NOW\")";
      fi

       qrencode -o address.png $KEYSTORECONTENT
       display address.png
     fi
  fi



      #  file exists and is a symbolic link
      # if [[ ! -L $HOMEDIR"/.poc/plotdata"]] ; then
      #     ln -s "$EHDDISKPATH"/p1/plotdata  $HOMEDIR"/.poc"
      # fi
}

##安装提示
Install
echo "安装结束"
