#!/bin/bash

############################################
#
# sudo apt-get install dos2unix
# dos2unix start.sh
#
###########################################


echo "=="$(date  +"%Y-%m-%d %H:%M:%S")"=="
mkdir log  >/dev/null 2>&1

STOPEDFILE=.stoped.flag
BIN=/ehd/bin/poc
IP=`/sbin/ifconfig | grep enp1s0 -A 3 | grep 'inet.*192' | awk -F' ' '{print $2}' | awk '{print $1}'`

Start() {
    echo "--------------------";
    echo "Starting Mining...";

    nohup $BIN \
	    --mine  --gcmode archive --syncmode=full  \
	    --networkid 10911 \
	    --rpc --rpcaddr "0.0.0.0" --rpcport="8545" --rpcapi "web3,peers,net,account,personal,eth,minedev,txpool" \
	    >> /ehd/log/poc.log &
	    #--debug --verbosity 5 --vmdebug \

      sleep 0.1;
      echo "-----";
      ps -elf | grep -E "$BIN\s" | grep -v grep;
      echo "DONE";
      rm -f $STOPEDFILE
}

Start
