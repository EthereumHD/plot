

[install guide]
https://github.com/EthereumHD/Doc/wiki/%E6%8C%96%E7%9F%BF%E5%B7%A5%E5%85%B7%E9%83%A8%E7%BD%B2%EF%BC%88%E9%80%82%E5%90%88%E5%BC%80%E5%8F%91%E8%80%85%EF%BC%89