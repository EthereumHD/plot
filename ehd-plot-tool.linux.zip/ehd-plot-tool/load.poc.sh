#!/bin/bash

############################################
#
#  sudo apt-get install dos2unix
#  dos2unix load.poc.sh
#
###########################################

CMD='./load.poc.sh'
STOPEDFILE=.stoped.flag
BIN='/ehd/bin/poc'

start() {
    echo "--------------------";
    echo "Starting private network";

    LOGDIR=$EHDPATH"/log"
    if [[ ! -d "$LOGDIR" ]]; then
        mkdir -p "$LOGDIR"
        chmod -R 0777 "$LOGDIR"
    fi

    nohup $BIN \
	    --mine  --gcmode archive --syncmode=full  \
	    --networkid 10911 \
	    --rpc --rpcaddr "0.0.0.0" --rpcport="8545" --rpcapi "web3,peers,net,account,personal,eth,minedev,txpool" \
	    >> /ehd/log/poc.log &
	    #--debug --verbosity 5 --vmdebug \


    sleep 0.1;
    echo "-----";
    ps -elf | grep -E "$BIN\s" | grep -v grep;
    echo "DONE";
    rm -f $STOPEDFILE
}

stop() {
    echo "Stop poc network";
    killflag=0
    pidlist=`ps -elf | grep -E "$BIN\s" | grep -v grep | awk '{print $4}'`;
    for pid in $pidlist;
    do
        killflag=1
        kill $pid ;
    done;

    if [ $killflag -ge 1 ]; then
        sleep 0.1;
        echo "-----";
        ps -elf | grep poc| grep -v grep;
        echo "stop done"
    else
        echo "$BIN is not running";
    fi
    touch $STOPEDFILE
}

restart() {
    stop;
    start;
}

install() {
    pocpath='/ehd';
    if [[ -f "$pocpath/bin/poc" ]]; then
        echo 'poc has been installed!'
        exit 1
    fi

    # apt-get update
    apt-get install sqlite3 jq dos2unix qrencode imagemagick net-tools language-pack-zh-hans vim*

    ########################################################################
    EHDPATH="/ehd"
    EHDDISKPATH="/ehd-disk"
    CURRENTDIR=`pwd`
    MAC=$(cat /sys/class/net/$(ip route show default | awk '/default/ {print $5}')/address)
    NOW=$(date +"%Y-%m-%d %H:%M:%S")
    HOMEDIR="/home/ehd"
    POCDIR=$HOMEDIR"/.poc"

    # <-/->
    sudo cp ./.vimrc ~

    if [[ ! -d "$POCDIR" ]]; then
        mkdir -p "$POCDIR"
        chmod -R 0777 "$POCDIR"
    fi

    LOGDIR=$EHDPATH"/log"
    if [[ ! -d "$LOGDIR" ]]; then
        mkdir -p "$LOGDIR"
        chmod -R 0777 "$LOGDIR"
    fi

    if [[ ! -d "$POCDIR"/keystore ]]; then
        mkdir -p "$POCDIR"/keystore
        chmod -R 0777 "$POCDIR"/keystore
    fi

    if [[ -f "$CURRENTDIR"/poc ]]; then
         if [[ ! -d "$EHDPATH"/bin ]]; then
            mkdir -p "$EHDPATH"/bin
         fi

         cp "$CURRENTDIR"/poc "$EHDPATH"/bin/poc
         chmod -R  0777 $EHDPATH
    fi

    chmod -R  0777 $EHDPATH
    chmod -R  0777 $POCDIR

    #创建矿机挖矿地址
    if [[ -f "$EHDPATH"/bin/poc ]]; then
      rm -fr "$POCDIR"/keystore/*
      rm -fr $CURRENTDIR/address-*
      rm -fr "$HOMEDIR"/桌面/UTC-*

      PASSWORD="ehd123123"
      # "$EHDPATH"/bin/poc account new --password "./password" --datadir $POCDIR
      echo -e $PASSWORD"\n"$PASSWORD"\n" | "$EHDPATH"/bin/poc account new --datadir $POCDIR
      cp -R "$POCDIR"/keystore/* "$HOMEDIR"/桌面
      chmod -R 0777 "$POCDIR"/keystore


    fi

    if [[ -f "$CURRENTDIR"/description.xml ]]; then
        cp "$CURRENTDIR"/description.xml "$POCDIR"
        chmod -R 0777 $POCDIR
    fi

    if [[ -f "$CURRENTDIR/database.sqlite" ]]; then
       cp "$CURRENTDIR/database.sqlite" "$EHDPATH"/bin
       cp "$CURRENTDIR/database.sqlite" "$EHDPATH"

       #make  filenames to be array
       KEYSTOREFILES=(`ls $POCDIR/keystore`)

       #echo "${files[maxIndex]}"
       maxIndex=${#KEYSTOREFILES[@]}-1
       FIRSTKEYSTOREFILE="${KEYSTOREFILES[$maxIndex]}"


       if [[ -f $POCDIR/keystore/$FIRSTKEYSTOREFILE ]] ; then
          KEYSTORECONTENT="`cat $POCDIR/keystore/$FIRSTKEYSTOREFILE`"

          ADDRESS=`cat $POCDIR/keystore/$FIRSTKEYSTOREFILE | jq '.address'`

          ADDRESS_REPLACED=${ADDRESS:1:40}
          ADDRESS="0x"$ADDRESS_REPLACED
          sqlite3 $CURRENTDIR/database.sqlite " DELETE FROM t_host;INSERT INTO t_host(F_Hostname, F_Status, F_CreateTime,F_ModifyTime) VALUES(\"EHD-miner-$MAC\",0,\"$NOW\",\"$NOW\");DELETE FROM t_user;INSERT INTO t_user(F_Username,F_Password, F_CreateTime, F_ModifyTime) VALUES(\"$ADDRESS\", \"ehd123123\", \"$NOW\", \"$NOW\");DELETE FROM t_plot;INSERT INTO t_plot(F_Name, F_Path, F_Uuid, F_PlotSeed, F_PlotDir, F_PlotSize, F_PlotParam, F_Status, F_CreateTime, F_ModifyTime) VALUES('', \"/ehd-disk/p1\", '',  \"$ADDRESS\",  \"/plotdata/\", \"8589934592\", '{\"startNonce\":0}', 1, \"$NOW\", \"$NOW\")";

          qrencode -o address-$ADDRESS.png $KEYSTORECONTENT
          display address-$ADDRESS.png
       fi
    fi

    #file exists and is a symbolic link
    if [[ ! -L $HOMEDIR"/.poc/plotdata" ]]; then
      ln -s "$EHDDISKPATH"/p1/plotdata  $HOMEDIR"/.poc"
    fi
    ########################################################################

    #Add Poc to CronJob
    cronconf="* * * * * cd $pocpath && ./load.poc.sh check >> /ehd/log/cron.log&"
    exist=`crontab -l | grep -F "$cronconf" | grep -v 'grep'`
    if [ "$exist" = "" ]; then
        (crontab -l 2>/dev/null | grep -Fv "$cronconf"; echo "$cronconf") | crontab -
        echo "add crontab[$cronconf] done"
    else
        echo "crontab[$cronconf] have exist! error"
    fi
}

check() {
    if [ -f ./$STOPEDFILE ]; then
        echo "it stoped, do nothing!!"
        exit 0
    fi
    pidlist=`ps -elf | grep -E "$BIN\s" | grep -v grep | awk '{print $4}'`
    if [ "$pidlist" = "" ] ;then
        echo "poc not exist, try treload";
        restart;
    else
        echo "poc is running, do nothing...";
    fi
}

format(){
  EHDDIR="/ehd"
  EHDDISKDIR="/ehd-disk"

  if [[ ! -d "$EHDDIR/bin" ]]; then
      mkdir -p "$EHDDIR/bin"
  fi
  chmod -R 0777 $EHDDIR

  # /ehd-disk/p1/plotdata 1-24
  if [[ ! -d $EHDDISKDIR ]]; then
    mkdir -p $EHDDISKDIR
  fi
  chmod -R 0777 $EHDDISKDIR

  for i in {1..24}
  do
    PLOTDATADIR="$EHDDISKDIR/p$i/plotdata"
    if [[ ! -d $PLOTDATADIR ]]; then
        mkdir -p $PLOTDATADIR
        chmod -R 0777 $PLOTDATADIR
    fi
  done

  #Ascii value of "a"
  ALETTERASCIIVALUE=97
  for i in {1..24}
  do
    PLOTDATADIR="$EHDDISKDIR/p$i"
    if ! grep -qs $PLOTDATADIR /proc/mounts; then
      CHARASCII=$[i + ALETTERASCIIVALUE]
      CHAR=$(echo $CHARASCII | awk '{printf("%c",$1)}')
      MOUNTDEVICE="/dev/sd$CHAR"

      #disk has been parted
      PARTIONFLAG="sd$CHAR"
      if ! grep -qs "$PARTIONFLAG" /proc/partions; then
        if [[ -b "$MOUNTDEVICE" ]]; then
           # 自动分区
           DEVINFO=$(file -s $MOUNTDEVICE)
           if [[ $DEVINFO != *"ext4"* ]]; then
            sudo  mkfs -t "ext4" $MOUNTDEVICE
           fi

           FREE=$(df -k --output=avail "$MOUNTDEVICE" | tail -n1)
           if [[ "$FREE" -gt "0" ]]; then
            sudo umount $MOUNTDEVICE
            sudo mount $MOUNTDEVICE $PLOTDATADIR
           fi
         fi
       fi
     fi
  done

  echo "Formated Disks are OK!"
}

mac() {
  #MAC
  MAC=$(cat /sys/class/net/$(ip route show default | awk '/default/ {print $5}')/address)
  echo $MAC
}

arg1=$1
if [ ! "$0" = "$CMD" ]; then
    echo "Error!!"
    echo "You should in correct directory "
    echo "And run command './load.poc.sh'"
    echo "Error!! "
    arg1="Error"
fi

case "$arg1" in
mac)
    mac
    ;;
format)
    format
    ;;
start)
    start
    ;;
stop)
    stop
    ;;
install)
    install
    ;;
check)
    check
    ;;
restart|reload)
    restart
    ;;
*)
    echo "Usage: $CMD {format|mac|install|check|start|stop|restart}"
    exit 1
esac
